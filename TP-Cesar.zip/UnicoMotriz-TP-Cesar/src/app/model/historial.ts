export class Historial{
  CHistorial:number=0;
  THistorial:string="";
  Reserva_CReserva:number=0;
}
