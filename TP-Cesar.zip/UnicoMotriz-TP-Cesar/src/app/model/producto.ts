export class Producto{
  nameProducto: string = "";
  nameCliente: string = "";
  emailCliente: string = "";
  claveCliente: string = "";
  claveProducto: string = "";
  telefonoCliente: string = "";
  vehiculoCliente: string = "";
}
