export class Cliente{
  id: number = 0;
  nameCliente: string = "";
  emailCliente: string = "";
  claveCliente: string = "";
  telefonoCliente: string = "";
  vehiculoCliente: string = "";
}
