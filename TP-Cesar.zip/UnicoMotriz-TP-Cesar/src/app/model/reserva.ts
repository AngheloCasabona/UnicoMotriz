import { Historial } from "./historial";

export class Reserva{
 CReserva: number=0;
 TDetalle:string="";
 historial: Historial=new Historial();
}
