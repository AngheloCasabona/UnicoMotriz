export class Taller {
  id:number =0;
  nameTaller:string = " ";
  addressTaller:string = " ";
}
