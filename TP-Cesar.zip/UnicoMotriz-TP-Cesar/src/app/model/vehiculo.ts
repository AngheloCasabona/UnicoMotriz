import { Cliente } from "./cliente";

export class Vehiculo{
  codeVehiculo: string = "";
  DAno: string = "";
  cliente: Cliente=new Cliente();
  NMarca: string = "";
  NModelo: string = "";
}
